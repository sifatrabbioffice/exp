# iOS IPA বিশ্লেষণ রিপোর্ট

## অ্যাপ্লিকেশন তথ্য
**অ্যাপ নাম:** Resident-Evil-4
**বিশ্লেষণ তারিখ:** Sun May 24 17:13:56 UTC 2026

## বাইনারি তথ্য
```
Payload/Resident Evil 4.app/AppIcon60x60@2x.png: PNG image data (CgBI), 120 x 120, 8-bit/color RGBA, non-interlaced
```

## সনাক্ত করা API এন্ডপয়েন্ট
```
```

## স্ট্রিং বিশ্লেষণ
মোট স্ট্রিং:      491
