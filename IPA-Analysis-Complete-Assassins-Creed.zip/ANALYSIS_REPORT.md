# iOS IPA বিশ্লেষণ রিপোর্ট

## অ্যাপ্লিকেশন তথ্য
**অ্যাপ নাম:** Assassins-Creed
**বিশ্লেষণ তারিখ:** Sun May 24 16:52:30 UTC 2026

## বাইনারি তথ্য
```
Payload/scimitar.app/localization.lang: data
```

## সনাক্ত করা API এন্ডপয়েন্ট
```
```

## স্ট্রিং বিশ্লেষণ
মোট স্ট্রিং:        1
